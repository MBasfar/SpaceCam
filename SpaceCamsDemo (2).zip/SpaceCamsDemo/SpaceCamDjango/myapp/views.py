import cv2
import os
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.urls import reverse

def home(request):
    return render(request, 'home.html')

def upload_video(request):
    if request.method == 'POST' and request.FILES.get('video'):
        # Save the uploaded video
        video = request.FILES['video']
        fs = FileSystemStorage()
        filename = fs.save(video.name, video)
        video_file_path = fs.path(filename)

        # Create a directory to store the frames
        frames_dir = os.path.join(settings.MEDIA_ROOT, 'frames', os.path.splitext(filename)[0])
        if not os.path.exists(frames_dir):
            os.makedirs(frames_dir)

        # OpenCV: Open the video and process
        capture = cv2.VideoCapture(video_file_path)
        fps = capture.get(cv2.CAP_PROP_FPS)
        frame_interval = int(fps / 2)  # Extract 2 frames per second

        frame_count = 0
        saved_frame_count = 0

        while True:
            ret, frame = capture.read()
            if not ret:
                break

            if frame_count % frame_interval == 0:
                # Save the current frame as an image
                frame_filename = os.path.join(frames_dir, f'frame_{saved_frame_count:04d}.jpg')
                cv2.imwrite(frame_filename, frame)
                saved_frame_count += 1

            frame_count += 1

        capture.release()

        # Redirect to the results page (without parameters)
        return redirect('results')

    return render(request, 'upload_video.html')

def results_page(request):
    # Simply render the results page with static content
    return render(request, 'results.html')

def telescope_feed (request):
    return render(request, 'telescope.html' )