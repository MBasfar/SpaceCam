from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Root URL for the home page
    path('upload/', views.upload_video, name='upload_video'),  # Upload page
    path('results/', views.results_page, name='results'),  # Results page
    path('telescope/', views.telescope_feed, name='telescope'),  # Telescope page
]
